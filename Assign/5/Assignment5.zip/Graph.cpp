#include "Graph.h"
#include <iostream>
#include <vector>
using namespace std;

Graph::Graph(){

}
Graph::~Graph(){
	
}

void Graph::addEdge(std::string v1, std::string v2, int weight){

}
void Graph::addVertex(std::string name){

}
void Graph::displayEdges(){

}
void Graph::assignDistricts(){
	BFTraversalLabel(vertices[0].name, 1);
	int counter = 1;
	for (int i=1;i<vertices.size(); i++){
		bool check=false;
		for (int j=1; j<= counter; j++){
			if (vertices[i].district==j){
				check=true;
			}
		}
		if (check==false){
			BFTraversalLabel(vertices[i].name, counter+1);
			counter++;
		}
	}
}
void Graph::shortestPath(std::string startingCity, std::string endingCity){

}

void BFTraversalLabel(std::string startingCity, int distID){
	vertex * temp;
	vertex temp2;

	std::queue<vertex> queueTraverse;
	for (int i=0; i<vertices.size(); i++){
		vertices[i].visited=0;
	}
	temp=findVertex(startingCity);
	temp->district=distID;
	temp->visited=true;
	queueTraverse.push_back(*temp);
	while (!queueTraverse.empty()){
		temp2=queueTraverse.front();
		queueTraverse.pop();
		for (int i=0;i<temp2.adj.size(); i++){
			if (!temp2.adj[i].v->visited){
				temp2.adj[i].v->visited=true;
				temp2.adj[i].v->district=distID;
				queueTraverse.push_back(*temp2.adj[i].v);
			}
		}
	}
}




